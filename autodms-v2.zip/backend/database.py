from supabase import create_client, Client
import os

SUPABASE_URL = os.environ.get("SUPABASE_URL", "https://owuvfxarzktcmrueculg.supabase.co")
SUPABASE_KEY = os.environ.get("SUPABASE_KEY", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im93dXZmeGFyemt0Y21ydWVjdWxnIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3ODY2MjU0OSwiZXhwIjoyMDk0MjM4NTQ5fQ.C9slu-9TawNuRWZDQgBObG3Dd7nSuT_zaFUbReE70Oc")

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
