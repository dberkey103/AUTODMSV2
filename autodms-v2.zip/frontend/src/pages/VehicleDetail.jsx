import React from 'react'
import { useParams } from 'react-router-dom'
export default function VehicleDetail() {
  const { id } = useParams()
  return <div className="p-6"><h1 className="text-xl font-bold">Vehicle Detail</h1><p className="text-gray-500 mt-1">Vehicle ID: {id}</p></div>
}
