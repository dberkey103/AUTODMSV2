import React from 'react'
export default function Service() {
  return <div className="p-6"><h1 className="text-xl font-bold">Service</h1><p className="text-gray-500 mt-1">Coming soon</p></div>
}
